package com.example.lab1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // ustawienie layoutu

        // rozwijana lista
        Spinner spinner = findViewById(R.id.spinner); // objekt spinnera, widok w xml

        String[] options = {"Wybierz aktywność", "Lab1", "Lab2"};

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, options); //adapter który przypisuje opcje do spinnera

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); //ustawienie wygladu elementow listy

        spinner.setAdapter(adapter); // przypisujemy adapter do spinnera

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            // Ta metoda jest wywoływana, gdy użytkownik wybiera coś z listy
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                if (position == 1) {
                    // Tworzymy intencję, aby przejść do Aktywności 1
                    Intent intent = new Intent(MainActivity.this, Activity1.class);
                    startActivity(intent); // Uruchamiamy nową aktywność
                }
                // Jeśli użytkownik wybrał "Aktywność 2"
                else if (position == 2) {
                    // Tworzymy intencję, aby przejść do Aktywności 2
                    Intent intent = new Intent(MainActivity.this, Activity2.class);
                    startActivity(intent); // Uruchamiamy nową aktywność
                }
            }

            // Ta metoda jest wywoływana, gdy nic nie jest wybrane (np. na początku, gdy Spinner jest pusty)
            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Można tutaj dodać logikę, która wykona się, gdy nic nie zostanie wybrane
            }
        });


    }
}
