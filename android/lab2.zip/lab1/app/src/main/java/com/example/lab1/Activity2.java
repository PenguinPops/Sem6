package com.example.lab1;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {

    private TextView imieLabel, nazwLabel, liczbaOcenLabel;
    private EditText imieInput, nazwInput, liczbaOcenInput;
    private Button ocenyButton;
    private TextView sredniaTextView;
    private Button superButton, niePoszloButton;

    // Metoda wywoływana, gdy użytkownik kliknie przycisk "Powrót"
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Metoda wywoływana, gdy aktywność jest tworzona
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);

        imieLabel = findViewById(R.id.imie);
        imieLabel.setText(R.string.imieStr);
        nazwLabel = findViewById(R.id.nazw);
        nazwLabel.setText(R.string.nazwStr);
        liczbaOcenLabel = findViewById(R.id.liczbaOcen);
        liczbaOcenLabel.setText(R.string.lOcenStr);
        imieInput = findViewById(R.id.imieInput);
        imieInput.setHint(R.string.imieHintStr);
        nazwInput = findViewById(R.id.nazwInput);
        nazwInput.setHint(R.string.nazwHintStr);
        liczbaOcenInput = findViewById(R.id.liczbaOcenInput);
        liczbaOcenInput.setHint(R.string.lOcenHintStr);
        ocenyButton = findViewById(R.id.ocenyButton);
        ocenyButton.setText(R.string.ocenyButtonStr);
        sredniaTextView = findViewById(R.id.sredniaTextView);
        superButton = findViewById(R.id.superButton);
        niePoszloButton = findViewById(R.id.niePoszloButton);

        ocenyButton.setEnabled(false);
        ocenyButton.setVisibility(View.GONE);

        imieInput.addTextChangedListener(watcher);
        nazwInput.addTextChangedListener(watcher);
        liczbaOcenInput.addTextChangedListener(watcher);

        // Ustawienie przycisku powrotu
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        // Obsługa przycisków superButton i niePoszloButton
        superButton.setOnClickListener(v -> {
            Toast.makeText(this, R.string.gratulacjeStr, Toast.LENGTH_SHORT).show();
            finish();
        });
        niePoszloButton.setOnClickListener(v -> {
            Toast.makeText(this, R.string.niePoszloStr, Toast.LENGTH_SHORT).show();
            finish();
        });
    }

    @SuppressLint("SetTextI18n")
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) { // onActivityResult obsługuje intent Extra z Activity 3
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            double srednia = data.getDoubleExtra("srednia", 0);

            sredniaTextView.setText("Średnia: " + srednia);
            sredniaTextView.setVisibility(View.VISIBLE);

            if (srednia >= 3) {
                superButton.setVisibility(View.VISIBLE);
                niePoszloButton.setVisibility(View.GONE);
            } else {
                niePoszloButton.setVisibility(View.VISIBLE);
                superButton.setVisibility(View.GONE);
            }
        }
    }

    private final TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {}

        @Override
        public void afterTextChanged(Editable s) {
            validateInput();
        }
    };

    private void validateInput() {
        String imie = imieInput.getText().toString().trim();
        String nazwisko = nazwInput.getText().toString().trim();
        String liczbaOcenStr = liczbaOcenInput.getText().toString().trim();

        boolean isValid = true;

        if (imie.isEmpty()) {
            imieInput.setError("Imię nie może być puste");
            isValid = false;
        } else {
            imieInput.setError(null);
        }

        if (nazwisko.isEmpty()) {
            nazwInput.setError("Nazwisko nie może być puste");
            isValid = false;
        } else {
            nazwInput.setError(null);
        }

        if (liczbaOcenStr.isEmpty()) {
            liczbaOcenInput.setError("Liczba ocen nie może być pusta");
            isValid = false;
        } else {
            try {
                int liczbaOcen = Integer.parseInt(liczbaOcenStr);
                if (liczbaOcen < 5 || liczbaOcen > 15) {
                    liczbaOcenInput.setError("Liczba ocen musi być w przedziale [5, 15]");
                    isValid = false;
                } else {
                    liczbaOcenInput.setError(null);
                }
            } catch (NumberFormatException e) {
                liczbaOcenInput.setError("Liczba ocen musi być liczbą całkowitą");
                isValid = false;
            }
        }

        if (isValid) {
            ocenyButton.setEnabled(true);
            ocenyButton.setVisibility(View.VISIBLE);
        } else {
            ocenyButton.setEnabled(false);
            ocenyButton.setVisibility(View.GONE);
        }
    }

    public void onOcenyClicked(View view) {
        int liczbaOcen = Integer.parseInt(liczbaOcenInput.getText().toString());
        Intent intent = new Intent(this, Activity3.class);
        intent.putExtra("liczbaOcen", liczbaOcen);
        startActivityForResult(intent, 1); // deprecated
    }
}