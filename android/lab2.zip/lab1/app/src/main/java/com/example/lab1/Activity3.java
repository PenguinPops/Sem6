package com.example.lab1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        int liczbaOcen = getIntent().getIntExtra("liczbaOcen", 0);

        if (liczbaOcen <= 0) {
            Toast.makeText(this, "Liczba ocen musi być większa od 0", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        LinearLayout layout = findViewById(R.id.ocenyLayout);
        String[] przedmioty = getResources().getStringArray(R.array.przedmioty);
        float[] oceny = {2, 3, 3.5f, 4, 4.5f, 5};

        for (int i = 0; i < liczbaOcen; i++) {
            TextView textView = new TextView(this);
            textView.setText(przedmioty[i % przedmioty.length]);
            layout.addView(textView);

            RadioGroup radioGroup = new RadioGroup(this);
            radioGroup.setOrientation(RadioGroup.HORIZONTAL);
            radioGroup.setTag(i); // Dodajemy tag z indeksem przedmiotu

            for (float ocena : oceny) {
                RadioButton radioButton = new RadioButton(this);
                radioButton.setText(String.valueOf(ocena));
                radioButton.setTag(ocena);
                radioGroup.addView(radioButton);
            }

            layout.addView(radioGroup);
        }

        Button obliczButton = findViewById(R.id.obliczButton);
        obliczButton.setOnClickListener(v -> {
            double suma = 0;
            int liczbaOcenObliczonych = 0;
            boolean wszystkieZaznaczone = true;

            // Sprawdzamy wszystkie RadioGroup
            for (int i = 0; i < layout.getChildCount(); i++) {
                View child = layout.getChildAt(i);
                if (child instanceof RadioGroup) {
                    RadioGroup radioGroup = (RadioGroup) child;
                    if (radioGroup.getCheckedRadioButtonId() == -1) {
                        wszystkieZaznaczone = false;
                        TextView przedmiotView = (TextView) layout.getChildAt(i-1);
                        Toast.makeText(this, "Wybierz ocenę dla przedmiotu: " + przedmiotView.getText(),
                                Toast.LENGTH_SHORT).show();
                        break;
                    }
                }
            }

            if (!wszystkieZaznaczone) {
                return;
            }

            // Jeśli wszystkie zaznaczone, obliczamy średnią
            for (int i = 0; i < layout.getChildCount(); i++) {
                View child = layout.getChildAt(i);
                if (child instanceof RadioGroup) {
                    RadioGroup radioGroup = (RadioGroup) child;
                    int selectedId = radioGroup.getCheckedRadioButtonId();
                    RadioButton selectedRadioButton = radioGroup.findViewById(selectedId);
                    float ocena = (float) selectedRadioButton.getTag();
                    suma += ocena;
                    liczbaOcenObliczonych++;
                }
            }

            double srednia = suma / liczbaOcenObliczonych;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("srednia", srednia);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }
}