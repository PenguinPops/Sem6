package com.example.lab1;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Activity3 extends AppCompatActivity {

    // Metoda wywoływana, gdy użytkownik kliknie przycisk "Powrót"
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Metoda wywoływana, gdy aktywność jest tworzona
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_3);

        // liczbaOcen jest przekazana z Activity2
        int liczbaOcen = getIntent().getIntExtra("liczbaOcen", 0);

        if (liczbaOcen <= 0) {
            Toast.makeText(this, "Liczba ocen musi być większa od 0", Toast.LENGTH_SHORT).show();
            finish();
        }

        LinearLayout layout = findViewById(R.id.ocenyLayout);

        String[] przedmioty = getResources().getStringArray(R.array.przedmioty); // pobranie nazw przedmiotów z pliku string.xml

        for (int i = 0; i < liczbaOcen; i++) {
            TextView textView = new TextView(this); // stworzenie obiektu TextView
            textView.setText(przedmioty[i % przedmioty.length]); // ustawienie tekstu na nazwę przedmiotu
            layout.addView(textView); // dodanie tekstu do LinearLayout

            EditText editText = new EditText(this); // stworzenie obiektu EditText
            editText.setHint("Ocena " + (i + 1)); // ustawienie podpowiedzi

            // Ustaw klawiaturę numeryczną
            editText.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);

            layout.addView(editText); // dodanie EditText do LinearLayout
        }

        Button obliczButton = findViewById(R.id.obliczButton);
        obliczButton.setOnClickListener(v -> {
            double suma = 0;
            int liczbaOcenObliczonych = 0;

            for (int i = 0; i < layout.getChildCount(); i++) { // przejście po wszystkich elementach LinearLayout
                View child = layout.getChildAt(i); // pobranie obecnego elementu
                if (child instanceof EditText) { // sprawdzenie, czy obecny element jest obiektem EditText (może być TextView)
                    String ocenaStr = ((EditText) child).getText().toString(); // pobranie tekstu z obiektu EditText
                    if (!ocenaStr.isEmpty()) {
                        try {
                            double ocena = Double.parseDouble(ocenaStr);
                            if (ocena >= 2 && ocena <= 5) {
                                suma += ocena;
                                liczbaOcenObliczonych++;
                            } else {
                                Toast.makeText(this, "Ocena musi być w zakresie 2-5", Toast.LENGTH_SHORT).show();
                                return;
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Nieprawidłowa ocena", Toast.LENGTH_SHORT).show();
                            return;
                        }
                    }
                }
            }

            if (liczbaOcenObliczonych == 0) {
                Toast.makeText(this, "Wprowadź oceny", Toast.LENGTH_SHORT).show();
                return;
            }

            double srednia = suma / liczbaOcenObliczonych;

            Intent resultIntent = new Intent();
            resultIntent.putExtra("srednia", srednia);
            setResult(RESULT_OK, resultIntent);
            finish();
        });
    }



}
