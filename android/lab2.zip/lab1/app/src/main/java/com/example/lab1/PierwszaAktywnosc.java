package com.example.lab1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class PierwszaAktywnosc extends AppCompatActivity
{
    //Tworzenie aktywności
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        //Tworzenie komponentów, odczytanie referencji
//        do elementów GUI, ustawienie obsługi zdarzeń,
//        odczytanie zapisanego stanu aktywności z obiektu
//        savedInstanceState
    }
    //Aktywność była niewidoczna
    protected void onRestart()
    {
        super.onRestart();
//Czynności wykonywane gdy aktywność wcześniej
//        istniała ale była niewidoczna
    }
    //Aktywność za chwilę stanie się widoczna
    @Override
    protected void onStart()
    {
        super.onStart();
//Tworzenie elementów niezbędnych do uaktualniania
//        i interfejsu użytkownika
    }
    //Aktywność jest na pierwszym planie
    @Override
    protected void onResume()
    {
        super.onResume();
    }
    //Aktywność traci "focus". Zostanie wprowadzona w stan
//    uśpienia (gdy system ma wznowić inną aktywność).
    @Override
    protected void onPause()
    {
        super.onPause();
//tutaj należy zwolnić zasoby i zapisać istotne dane
//        w trwałym magazynie. Implementacja powinna być szybka
//        bo system nie wznowi innej aktywności dopóki
//        ta metoda się nie zakończy.
    }
    //Aktywność nie jest widoczna. Została wstrzymana.
    @Override
    protected void onStop()
    {
        super.onStop();
//tutaj należy zwolnić zasoby i zapisać istotne
//        elementy stanu. Po wykonaniu tej metody proces
//        z tą aktywnością może zostać "zabity" przez system
//        (bez wykonania kolejnych metod cyklu życia).
    }
    //Za chwilę aktywność zostanie zniszczona (tymczasowo lub
//    w celu zwolnienia pamięci)
    @Override
    protected void onDestroy()
    {
        super.onDestroy();
//po wykonaniu tej metody proces z tą aktywnością
//        może zostać "zabity" przez system (bez wykonania
//        kolejnych metod cyklu życia).
    }
}