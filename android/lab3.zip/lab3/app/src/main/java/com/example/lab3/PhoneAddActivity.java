package com.example.lab3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.lab3.dbfiles.Phone;
import com.example.lab3.Components.PhoneViewModel;

public class PhoneAddActivity extends AppCompatActivity {

    private EditText mManufacturerEditText;
    private EditText mModelEditText;
    private EditText mVersionEditText;
    private EditText mUrlEditText;

    private Button saveButton;
    private Button cancelButton;
    private Button webpageButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_add);

        PhoneViewModel mPhoneViewModel = new ViewModelProvider(this).get(PhoneViewModel.class);

        mManufacturerEditText = findViewById(R.id.editTextManufacturer);
        mModelEditText = findViewById(R.id.editTextModel);
        mVersionEditText = findViewById(R.id.editTextAndroidVersion);
        mUrlEditText = findViewById(R.id.editTextWebsite);

        saveButton = findViewById(R.id.buttonSave);
        cancelButton = findViewById(R.id.buttonCancel);
        webpageButton = findViewById(R.id.buttonWebsite);

        final Phone phone = (Phone) getIntent().getSerializableExtra("phone");
        if (phone != null) {
            mManufacturerEditText.setText(phone.getManufacturer());
            mModelEditText.setText(phone.getModel());
            mVersionEditText.setText(phone.getAndroidVersion());
            mUrlEditText.setText(phone.getWebsite());
        }

        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateInput()) {
                    String manufacturer = mManufacturerEditText.getText().toString();
                    String model = mModelEditText.getText().toString();
                    String androidVersion = mVersionEditText.getText().toString();
                    String website = mUrlEditText.getText().toString();

                    if (phone == null) {
                        Phone phone1 = new Phone(
                                manufacturer,
                                model,
                                androidVersion,
                                website
                        );
                        mPhoneViewModel.insert(phone1);
                    } else {
                        phone.setId(phone.getId());
                        phone.setManufacturer(manufacturer);
                        phone.setModel(model);
                        phone.setAndroidVersion(androidVersion);
                        phone.setWebsite(website);
                        mPhoneViewModel.update(phone);
                    }
                    finish();
                }
            }
        });

        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        webpageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (validateUrl()) {
                    openWebsite();
                }
            }
        });
    }

    private boolean validateInput() {
        boolean isValid = true;

        if (mManufacturerEditText.getText().toString().trim().isEmpty()) {
            mManufacturerEditText.setError("Manufacturer cannot be empty");
            isValid = false;
        }

        if (mModelEditText.getText().toString().trim().isEmpty()) {
            mModelEditText.setError("Model cannot be empty");
            isValid = false;
        }

        if (mVersionEditText.getText().toString().trim().isEmpty()) {
            mVersionEditText.setError("Android version cannot be empty");
            isValid = false;
        }

        if (!validateUrl()) {
            isValid = false;
        }

        return isValid;
    }

    private boolean validateUrl() {
        String url = mUrlEditText.getText().toString().trim();
        if (url.isEmpty()) {
            mUrlEditText.setError("Website cannot be empty");
            return false;
        }

        // Basic URL format validation
        if (!(url.startsWith("www.") && url.endsWith(".com"))) {
            mUrlEditText.setError("Please use the correct URL format (e.g., www.example.com)");
            return false;
        }

        return true;
    }

    private void openWebsite() {
        String url = mUrlEditText.getText().toString();
        try {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            startActivity(browserIntent);
        } catch (Exception e) {
            Toast.makeText(this, "Invalid website URL", Toast.LENGTH_SHORT).show();
        }
    }
}