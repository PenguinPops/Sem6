package com.example.lab3.Components;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.lab3.R;
import com.example.lab3.dbfiles.Phone;

import java.util.ArrayList;
import java.util.List;

public class PhoneListAdapter extends RecyclerView.Adapter<PhoneListAdapter.PhoneViewHolder> {
    private List<Phone> mPhones;
    private OnItemClickListener mListener;

    public PhoneListAdapter() {
        mPhones = new ArrayList<>();
    }

    public interface OnItemClickListener {
        void onItemClick(Phone phone);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mListener = listener;
    }

    @NonNull
    @Override
    public PhoneViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recyclerview_item, parent, false);
        return new PhoneViewHolder(itemView, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull PhoneViewHolder holder, int position) {
        Phone current = mPhones.get(position);
        holder.manufacturerTextView.setText(current.getManufacturer());
        holder.modelTextView.setText(current.getModel());
        holder.itemView.setTag(current);
    }

    @Override
    public int getItemCount() {
        return mPhones.size();
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setPhones(List<Phone> phones) {
        mPhones = phones;
        notifyDataSetChanged();
    }

    // Dodana nowa metoda do pobierania telefonu na danej pozycji
    public Phone getPhoneAtPosition(int position) {
        if (position >= 0 && position < mPhones.size()) {
            return mPhones.get(position);
        }
        return null;
    }

    class PhoneViewHolder extends RecyclerView.ViewHolder {
        private TextView manufacturerTextView;
        private TextView modelTextView;

        public PhoneViewHolder(@NonNull View itemView, final OnItemClickListener listener) {
            super(itemView);
            manufacturerTextView = itemView.findViewById(R.id.manufacturerTextView);
            modelTextView = itemView.findViewById(R.id.modelTextView);

            itemView.setOnClickListener(view -> {
                if (listener != null) {
                    int position = getAdapterPosition();
                    if(position != RecyclerView.NO_POSITION) {
                        listener.onItemClick((Phone) itemView.getTag());
                    }
                }
            });
        }
    }
}