package com.example.lab1;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends AppCompatActivity {

    private EditText imieInput, nazwInput, liczbaOcenInput;
    private Button ocenyButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_1);

        imieInput = findViewById(R.id.imieInput);
        nazwInput = findViewById(R.id.nazwInput);
        liczbaOcenInput = findViewById(R.id.liczbaOcenInput);
        ocenyButton = findViewById(R.id.ocenyButton);

        ocenyButton.setEnabled(false);
        ocenyButton.setVisibility(View.GONE);

        imieInput.addTextChangedListener(watcher);
        nazwInput.addTextChangedListener(watcher);
        liczbaOcenInput.addTextChangedListener(watcher);
    }

    private final TextWatcher watcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {

        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {

        }

        @Override
        public void afterTextChanged(Editable s) {
            validateInput();
        }
    };

    private void validateInput() {
        String imie = imieInput.getText().toString().trim();
        String nazwisko = nazwInput.getText().toString().trim();
        String liczbaOcenStr = liczbaOcenInput.getText().toString().trim();

        boolean isValid = true;

        // Walidacja imienia
        if (imie.isEmpty()) {
            imieInput.setError("Imię nie może być puste");
            isValid = false;
        } else {
            imieInput.setError(null);
        }

        // Walidacja nazwiska
        if (nazwisko.isEmpty()) {
            nazwInput.setError("Nazwisko nie może być puste");
            isValid = false;
        } else {
            nazwInput.setError(null);
        }

        // Walidacja liczby ocen
        if (liczbaOcenStr.isEmpty()) {
            liczbaOcenInput.setError("Liczba ocen nie może być pusta");
            isValid = false;
        } else {
            try {
                int liczbaOcen = Integer.parseInt(liczbaOcenStr);
                if (liczbaOcen < 5 || liczbaOcen > 15) {
                    liczbaOcenInput.setError("Liczba ocen musi być w przedziale [5, 15]");
                    isValid = false;
                } else {
                    liczbaOcenInput.setError(null);
                }
            } catch (NumberFormatException e) {
                liczbaOcenInput.setError("Liczba ocen musi być liczbą całkowitą");
                isValid = false;
            }
        }

        if(isValid) {
            ocenyButton.setEnabled(true);
            ocenyButton.setVisibility(View.VISIBLE);
        }
        if (!isValid) {
            Toast.makeText(Activity1.this, "Proszę poprawić dane", Toast.LENGTH_SHORT).show();
            ocenyButton.setEnabled(false);
            ocenyButton.setVisibility(View.GONE);
        }
    }

    public void onOcenyClicked(View view) {
        Toast.makeText(this, "Przycisk 'Oceny' kliknięty!", Toast.LENGTH_SHORT).show();
    }
}
