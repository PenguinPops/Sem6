package com.example.lab1;

import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {
}
